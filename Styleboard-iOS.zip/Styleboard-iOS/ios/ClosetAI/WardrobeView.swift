import CoreImage
import PhotosUI
import SwiftUI
import UIKit
import Vision

struct WardrobeView: View {
    @EnvironmentObject private var closet: ClosetStore
    @State private var photo: PhotosPickerItem?
    @State private var selectedItem: WardrobeItem?
    @State private var showAddSource = false
    @State private var showPhotoLibrary = false
    @State private var showCamera = false

    private let columns = [GridItem(.adaptive(minimum: 150), spacing: 14)]

    var body: some View {
        ScrollView {
            if closet.items.isEmpty && !closet.isLoading {
                ContentUnavailableView("Your wardrobe is empty", systemImage: "hanger", description: Text("Add one garment per photo. Analysis runs privately on this iPhone."))
                    .padding(.top, 54)
            } else {
                LazyVGrid(columns: columns, spacing: 14) {
                    ForEach(closet.items) { item in
                        Button { selectedItem = item } label: { WardrobeCard(item: item) }
                            .buttonStyle(.plain)
                    }
                }
                .padding()
            }
        }
        .safeAreaInset(edge: .top, spacing: 0) {
            BrandSectionHeader(title: "Wardrobe") {
                Button { showAddSource = true } label: { Label("Add clothing", systemImage: "plus") }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .confirmationDialog("Add garment", isPresented: $showAddSource, titleVisibility: .visible) {
            Button("Take Photo") {
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    showCamera = true
                } else {
                    closet.errorMessage = "A camera is not available on this device."
                }
            }
            Button("Choose from Photo Library") { showPhotoLibrary = true }
            Button("Cancel", role: .cancel) {}
        }
        .photosPicker(isPresented: $showPhotoLibrary, selection: $photo, matching: .images)
        .fullScreenCover(isPresented: $showCamera) {
            CameraPicker { image in importImage(image) }
                .ignoresSafeArea()
        }
        .overlay { if closet.isLoading { ProgressView("Analyzing on this iPhone…").padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14)) } }
        .onChange(of: photo) { _, value in
            guard let value else { return }
            Task {
                defer { photo = nil }
                guard let data = try? await value.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else {
                    closet.errorMessage = "That photo could not be prepared for upload."
                    return
                }
                importImage(image)
            }
        }
        .sheet(item: $selectedItem) { ItemEditorView(item: $0) }
        .alert("Analysis needs review", isPresented: Binding(get: { closet.notice != nil }, set: { if !$0 { closet.notice = nil } })) {
            Button("OK") { closet.notice = nil }
        } message: { Text(closet.notice ?? "") }
    }

    private func importImage(_ image: UIImage) {
        guard let jpeg = image.jpegData(compressionQuality: 0.82) else {
            closet.errorMessage = "That photo could not be prepared."
            return
        }
        Task {
            let analysis = await LocalGarmentAnalyzer.analyze(jpeg)
            await closet.upload(jpeg, analysis: analysis)
        }
    }
}

private struct CameraPicker: UIViewControllerRepresentable {
    let onImage: (UIImage) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onImage: onImage) }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.cameraCaptureMode = .photo
        picker.allowsEditing = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        private let onImage: (UIImage) -> Void

        init(onImage: @escaping (UIImage) -> Void) { self.onImage = onImage }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let image = info[.originalImage] as? UIImage { onImage(image) }
            picker.dismiss(animated: true)
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }
}

private enum LocalGarmentAnalyzer {
    static func analyze(_ data: Data) async -> GarmentAnalysis {
        await Task.detached(priority: .userInitiated) {
            guard let image = UIImage(data: data), let cgImage = image.cgImage else { return fallback() }
            let request = VNClassifyImageRequest()
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            try? handler.perform([request])
            let observations = request.results ?? []
            let labels = observations.prefix(12).map(\.identifier).joined(separator: " ").lowercased()
            let (category, subcategory) = garmentType(from: labels)
            let color = dominantColor(in: data)
            let confidence = Double(observations.first?.confidence ?? 0.35)
            let formality = labels.containsAny(["suit", "blazer", "loafer", "oxford", "gown", "dress shirt"]) ? "Dressy" : "Casual"
            let pattern = labels.containsAny(["stripe", "plaid", "checkered", "floral", "polka dot"]) ? "Patterned" : "Solid"
            let material = labels.contains("denim") ? "Denim" : labels.contains("leather") ? "Leather" : labels.containsAny(["knit", "sweater", "jersey"]) ? "Knit" : "Unknown"
            let style = formality == "Dressy" ? "polished" : "casual"
            return GarmentAnalysis(
                name: "\(color) \(subcategory)".capitalized,
                category: category,
                subcategory: subcategory,
                primaryColor: color,
                secondaryColors: [],
                pattern: pattern,
                material: material,
                fit: "Unknown",
                silhouette: "Unknown",
                formality: formality,
                season: defaultSeasons(for: category, labels: labels),
                styleTags: [style, colorStyle(color)],
                layering: category == "Outerwear" ? "Wear as a finishing layer." : "Review layering based on fit and weather.",
                bestColorPartners: colorPartners[color.lowercased()] ?? ["Black", "White", "Gray"],
                avoidColorPartners: [],
                stylingNotes: "Analyzed privately on this iPhone. Review any details the camera could not determine.",
                confidence: min(max(confidence, 0.25), 0.95)
            )
        }.value
    }

    private static func garmentType(from labels: String) -> (String, String) {
        if labels.containsAny(["dress", "gown", "jumpsuit", "romper"]) { return ("One-piece", labels.contains("gown") ? "Gown" : "Dress") }
        if labels.containsAny(["shoe", "sneaker", "loafer", "boot", "sandal", "slipper", "footwear"]) { return ("Shoes", labels.contains("boot") ? "Boots" : labels.contains("sandal") ? "Sandals" : labels.contains("loafer") ? "Loafers" : "Shoes") }
        if labels.containsAny(["coat", "jacket", "blazer", "cardigan", "hoodie", "parka", "outerwear"]) { return ("Outerwear", labels.contains("blazer") ? "Blazer" : labels.contains("coat") ? "Coat" : "Jacket") }
        if labels.containsAny(["trouser", "pants", "jeans", "shorts", "skirt", "bottom"]) { return ("Bottoms", labels.contains("jeans") ? "Jeans" : labels.contains("shorts") ? "Shorts" : labels.contains("skirt") ? "Skirt" : "Pants") }
        if labels.containsAny(["bag", "purse", "belt", "hat", "scarf", "tie", "watch", "jewelry", "sunglass"]) { return ("Accessories", "Accessory") }
        if labels.containsAny(["shirt", "t-shirt", "tee", "polo", "blouse", "sweater", "jersey", "top"]) { return ("Tops", labels.contains("polo") ? "Polo" : labels.containsAny(["sweater", "jersey"]) ? "Sweater" : "Top") }
        return ("Tops", "Garment")
    }

    private static func dominantColor(in data: Data) -> String {
        guard let input = CIImage(data: data), let filter = CIFilter(name: "CIAreaAverage") else { return "Unknown" }
        filter.setValue(input, forKey: kCIInputImageKey)
        filter.setValue(CIVector(cgRect: input.extent), forKey: kCIInputExtentKey)
        guard let output = filter.outputImage else { return "Unknown" }
        var pixel = [UInt8](repeating: 0, count: 4)
        CIContext().render(output, toBitmap: &pixel, rowBytes: 4, bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: .RGBA8, colorSpace: CGColorSpaceCreateDeviceRGB())
        let palette: [(String, (Int, Int, Int))] = [
            ("Black", (25, 25, 25)), ("White", (235, 235, 235)), ("Gray", (130, 130, 130)),
            ("Navy", (30, 48, 88)), ("Blue", (45, 105, 180)), ("Brown", (105, 70, 45)),
            ("Beige", (200, 180, 140)), ("Red", (180, 45, 45)), ("Green", (55, 120, 70)),
            ("Olive", (100, 105, 55)), ("Purple", (120, 70, 145)), ("Pink", (215, 135, 160)),
            ("Orange", (220, 120, 45)), ("Yellow", (220, 190, 60))
        ]
        let rgb = (Int(pixel[0]), Int(pixel[1]), Int(pixel[2]))
        return palette.min { left, right in distance(rgb, left.1) < distance(rgb, right.1) }?.0 ?? "Unknown"
    }

    private static func distance(_ a: (Int, Int, Int), _ b: (Int, Int, Int)) -> Int {
        let red = a.0 - b.0, green = a.1 - b.1, blue = a.2 - b.2
        return red * red + green * green + blue * blue
    }

    private static func defaultSeasons(for category: String, labels: String) -> [String] {
        if labels.containsAny(["coat", "parka", "sweater", "boot"]) { return ["Fall", "Winter"] }
        if labels.containsAny(["shorts", "sandal", "tank top"]) { return ["Spring", "Summer"] }
        return ["All seasons"]
    }

    private static func colorStyle(_ color: String) -> String {
        ["Black", "White", "Gray", "Navy", "Beige", "Brown"].contains(color) ? "neutral" : "colorful"
    }

    private static let colorPartners: [String: [String]] = [
        "black": ["White", "Gray", "Beige", "Red"], "white": ["Navy", "Black", "Blue", "Olive"],
        "navy": ["White", "Beige", "Gray", "Brown"], "blue": ["White", "Beige", "Gray"],
        "brown": ["Beige", "Navy", "White", "Olive"], "beige": ["Navy", "White", "Brown", "Olive"],
        "gray": ["Black", "White", "Navy", "Pink"], "red": ["Black", "White", "Navy"],
        "green": ["White", "Beige", "Brown"], "olive": ["White", "Beige", "Brown", "Navy"]
    ]

    private static func fallback() -> GarmentAnalysis {
        GarmentAnalysis(name: "New garment", category: "Tops", subcategory: "Garment", primaryColor: "Unknown", secondaryColors: [], pattern: "Unknown", material: "Unknown", fit: "Unknown", silhouette: "Unknown", formality: "Unknown", season: ["All seasons"], styleTags: [], layering: "Review based on fit and weather.", bestColorPartners: [], avoidColorPartners: [], stylingNotes: "Review and edit this item.", confidence: 0)
    }
}

private extension String {
    func containsAny(_ terms: [String]) -> Bool { terms.contains(where: contains) }
}

private struct WardrobeCard: View {
    let item: WardrobeItem
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            GarmentImage(url: item.imageURL)
                .frame(height: 180)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            Text(item.name).font(.headline).lineLimit(1)
            Text("\(item.category) · \(item.analysis.primaryColor)").font(.caption).foregroundStyle(.secondary).lineLimit(1)
            if item.dirty || !item.available {
                Label(item.dirty ? "In laundry" : "Unavailable", systemImage: "clock").font(.caption2).foregroundStyle(.orange)
            }
        }
        .padding(10)
        .background(.background, in: RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 8, y: 3)
    }
}

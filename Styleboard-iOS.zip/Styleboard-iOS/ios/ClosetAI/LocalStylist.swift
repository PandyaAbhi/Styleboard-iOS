import Foundation

enum LocalStylist {
    private struct Candidate {
        let items: [WardrobeItem]
        let score: Double
        let vibe: String
        let reason: String
        let styling: String
    }

    private static let neutralColors = Set(["black", "white", "gray", "grey", "navy", "beige", "brown", "cream", "denim", "unknown"])

    static func generate(items: [WardrobeItem], recent: [Outfit], profile: StyleProfile, context: OutfitContext, limit: Int = 3) throws -> (outfits: [Outfit], notice: String) {
        let available = items.filter { eligible($0, context: context) }
        let shoes = available.filter { $0.category == "Shoes" }
        let tops = available.filter { $0.category == "Tops" }
        let bottoms = available.filter { $0.category == "Bottoms" }
        let onePieces = available.filter { $0.category == "One-piece" }
        let outerwear = available.filter { $0.category == "Outerwear" }
        let accessories = available.filter { $0.category == "Accessories" }
        guard !shoes.isEmpty, !onePieces.isEmpty || (!tops.isEmpty && !bottoms.isEmpty) else { throw LocalClosetError.insufficientWardrobe }

        var candidates: [Candidate] = []
        var seed = 0
        for top in tops {
            for bottom in bottoms {
                for shoe in shoes {
                    var pieces = [top, bottom, shoe]
                    if !outerwear.isEmpty, context.temperatureC == nil || context.temperatureC! < 22 || seed.isMultiple(of: 2) { pieces.append(outerwear[seed % outerwear.count]) }
                    if !accessories.isEmpty, seed.isMultiple(of: 3) { pieces.append(accessories[seed % accessories.count]) }
                    candidates.append(candidate(pieces, profile: profile, context: context, seed: seed))
                    seed += 1
                }
            }
        }
        for onePiece in onePieces {
            for shoe in shoes {
                var pieces = [onePiece, shoe]
                if !outerwear.isEmpty, context.temperatureC == nil || context.temperatureC! < 22 || seed.isMultiple(of: 2) { pieces.append(outerwear[seed % outerwear.count]) }
                if !accessories.isEmpty, seed.isMultiple(of: 2) { pieces.append(accessories[seed % accessories.count]) }
                candidates.append(candidate(pieces, profile: profile, context: context, seed: seed))
                seed += 1
            }
        }

        let byID = Dictionary(uniqueKeysWithValues: available.map { ($0.id, $0) })
        let recentWhole = Set(recent.prefix(30).map { signature($0.itemIDs) })
        let recentCore = Set(recent.prefix(30).map { coreSignature($0.itemIDs, byID: byID) })
        var accepted: [Candidate] = []
        for candidate in candidates.sorted(by: { $0.score > $1.score }) {
            let ids = candidate.items.map(\.id)
            guard Set(ids).count == ids.count, !recentWhole.contains(signature(ids)), !recentCore.contains(coreSignature(ids, byID: byID)), validCategories(candidate.items) else { continue }
            let core = Set(candidate.items.filter { !["Outerwear", "Accessories"].contains($0.category) }.map(\.id))
            let tooSimilar = accepted.contains { acceptedCandidate in
                let otherCore = Set(acceptedCandidate.items.filter { !["Outerwear", "Accessories"].contains($0.category) }.map(\.id))
                return core.intersection(otherCore).count > min(core.count, otherCore.count) - 2
            }
            guard !tooSimilar else { continue }
            accepted.append(candidate)
            if accepted.count == limit { break }
        }

        let outfits = accepted.map { candidate in
            Outfit(id: UUID(), itemIDs: candidate.items.map(\.id), score: candidate.score, vibe: candidate.vibe, reason: candidate.reason, styling: candidate.styling, occasion: context.occasion, context: context, saved: false, feedback: nil, createdAt: .now)
        }
        return (outfits, outfits.count < limit ? "Fewer than three distinct new looks are available for this wardrobe and context." : "")
    }

    static func deriveProfile(items: [WardrobeItem], outfits: [Outfit], notes: String) -> StyleProfile {
        var colors: [String: Int] = [:], styles: [String: Int] = [:], fits: [String: Int] = [:]
        func add(_ item: WardrobeItem, weight: Int) {
            if normalized(item.analysis.primaryColor) != "unknown" { colors[normalized(item.analysis.primaryColor), default: 0] += weight }
            for value in item.analysis.styleTags where normalized(value) != "unknown" { styles[normalized(value), default: 0] += weight }
            if normalized(item.analysis.fit) != "unknown" { fits[normalized(item.analysis.fit), default: 0] += weight }
        }
        items.forEach { add($0, weight: 1) }
        for outfit in outfits {
            let weight = outfit.saved ? 3 : outfit.feedback == "like" ? 2 : outfit.feedback == "dislike" ? -3 : 0
            guard weight != 0 else { continue }
            outfit.itemIDs.compactMap { id in items.first(where: { $0.id == id }) }.forEach { add($0, weight: weight) }
        }
        func preferred(_ values: [String: Int], limit: Int) -> [String] { values.filter { $0.value > 0 }.sorted { $0.value > $1.value }.prefix(limit).map(\.key) }
        return StyleProfile(preferredColors: preferred(colors, limit: 5), preferredStyles: preferred(styles, limit: 5), preferredFits: preferred(fits, limit: 3), avoidStyles: styles.filter { $0.value < 0 }.sorted { $0.value < $1.value }.map(\.key), notes: notes, feedbackCount: outfits.filter { $0.saved || $0.feedback != nil }.count)
    }

    private static func candidate(_ pieces: [WardrobeItem], profile: StyleProfile, context: OutfitContext, seed: Int) -> Candidate {
        let names = pieces.map(\.name)
        let colors = Array(Set(pieces.map { $0.analysis.primaryColor }.filter { $0 != "Unknown" })).sorted()
        let vibe = context.vibe.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Put together" : context.vibe
        let palette = colors.isEmpty ? "balanced proportions" : "\(colors.joined(separator: ", ")) palette"
        let outerwear = pieces.first { $0.category == "Outerwear" }
        let shoe = pieces.first { $0.category == "Shoes" }
        let tip = outerwear.map { "Wear the \($0.name) as the finishing layer and keep the rest streamlined around the \(shoe?.name ?? "shoes")." } ?? "Keep the proportions clean and let the \(shoe?.name ?? "shoes") finish the outfit."
        return Candidate(items: pieces, score: score(pieces, profile: profile, context: context, seed: seed), vibe: vibe, reason: "\(names.joined(separator: ", ")) form a \(vibe.lowercased()) outfit with a cohesive \(palette).", styling: tip)
    }

    private static func score(_ pieces: [WardrobeItem], profile: StyleProfile, context: OutfitContext, seed: Int) -> Double {
        var value = 68 + seed % 7
        for left in pieces.indices {
            for right in pieces.indices where right > left {
                let leftColor = normalized(pieces[left].analysis.primaryColor), rightColor = normalized(pieces[right].analysis.primaryColor)
                let leftPartners = Set(pieces[left].analysis.bestColorPartners.map(normalized))
                let rightPartners = Set(pieces[right].analysis.bestColorPartners.map(normalized))
                if leftColor == rightColor && leftColor != "unknown" { value += 2 }
                else if neutralColors.contains(leftColor) || neutralColors.contains(rightColor) { value += 3 }
                else if leftPartners.contains(rightColor) || rightPartners.contains(leftColor) { value += 5 }
            }
        }
        let preferredColors = Set(profile.preferredColors.map(normalized)), preferredStyles = Set(profile.preferredStyles.map(normalized)), avoided = Set(profile.avoidStyles.map(normalized))
        for piece in pieces {
            if preferredColors.contains(normalized(piece.analysis.primaryColor)) { value += 2 }
            let tags = Set(piece.analysis.styleTags.map(normalized))
            if !tags.intersection(preferredStyles).isEmpty { value += 2 }
            if !tags.intersection(avoided).isEmpty { value -= 5 }
        }
        if let temperature = context.temperatureC, temperature < 18, pieces.contains(where: { $0.category == "Outerwear" }) { value += 4 }
        return Double(max(45, min(98, value)))
    }

    private static func eligible(_ item: WardrobeItem, context: OutfitContext) -> Bool {
        guard item.available, !item.dirty else { return false }
        if !context.season.isEmpty, !item.analysis.season.isEmpty {
            let seasons = item.analysis.season.map(normalized)
            guard seasons.contains(normalized(context.season)) || seasons.contains("all seasons") || seasons.contains("year-round") else { return false }
        }
        if let temperature = context.temperatureC, temperature >= 28 {
            let description = normalized("\(item.analysis.material) \(item.analysis.subcategory)")
            if ["wool", "heavy", "insulated", "puffer"].contains(where: description.contains) { return false }
        }
        return true
    }

    private static func validCategories(_ items: [WardrobeItem]) -> Bool {
        let counts = Dictionary(grouping: items, by: \.category).mapValues { $0.count }
        let separates = counts["Tops"] == 1 && counts["Bottoms"] == 1 && counts["One-piece"] == nil
        let onePiece = counts["One-piece"] == 1 && counts["Tops"] == nil && counts["Bottoms"] == nil
        return counts["Shoes"] == 1 && (separates || onePiece) && (counts["Outerwear"] ?? 0) <= 1 && (counts["Accessories"] ?? 0) <= 3
    }

    private static func signature(_ ids: [UUID]) -> String { ids.map(\.uuidString).sorted().joined(separator: "|") }
    private static func coreSignature(_ ids: [UUID], byID: [UUID: WardrobeItem]) -> String { signature(ids.filter { id in byID[id].map { !["Outerwear", "Accessories"].contains($0.category) } ?? false }) }
    private static func normalized(_ value: String) -> String { value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
}

import SwiftUI
import UIKit

struct GarmentImage: View {
    let url: URL

    var body: some View {
        Group {
            if let image = UIImage(contentsOfFile: url.path) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Rectangle().fill(.quaternary).overlay { Image(systemName: "photo").foregroundStyle(.secondary) }
            }
        }
    }
}

struct OutfitCard: View {
    @EnvironmentObject private var closet: ClosetStore
    let outfit: Outfit

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                VStack(alignment: .leading) {
                    Text(outfit.occasion.uppercased()).font(.caption.bold()).foregroundStyle(.indigo)
                    Text(outfit.vibe).font(.title3.bold())
                }
                Spacer()
                Text("\(Int(outfit.score))/100").font(.headline.monospacedDigit())
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(outfit.itemIDs, id: \.self) { id in
                        if let item = closet.items.first(where: { $0.id == id }) {
                            VStack(alignment: .leading) {
                                GarmentImage(url: item.imageURL)
                                    .frame(width: 115, height: 125).clipShape(RoundedRectangle(cornerRadius: 12))
                                Text(item.name).font(.caption.bold()).lineLimit(1).frame(width: 115, alignment: .leading)
                            }
                        }
                    }
                }
            }
            Label("Why it works", systemImage: "checkmark.seal.fill").font(.subheadline.bold())
            Text(outfit.reason).font(.subheadline).foregroundStyle(.secondary)
            Label("Styling tip", systemImage: "wand.and.stars").font(.subheadline.bold())
            Text(outfit.styling).font(.subheadline).foregroundStyle(.secondary)
            HStack {
                Button { Task { await closet.setFeedback(outfit, feedback: "like") } } label: { Label("Like", systemImage: outfit.feedback == "like" ? "hand.thumbsup.fill" : "hand.thumbsup") }
                Button { Task { await closet.setFeedback(outfit, feedback: "dislike") } } label: { Label("Dislike", systemImage: outfit.feedback == "dislike" ? "hand.thumbsdown.fill" : "hand.thumbsdown") }
                Spacer()
                Button { Task { await closet.setFeedback(outfit, saved: !outfit.saved) } } label: { Label(outfit.saved ? "Saved" : "Save", systemImage: outfit.saved ? "heart.fill" : "heart") }
            }
            .buttonStyle(.bordered)
            .labelStyle(.iconOnly)
        }
        .padding()
        .background(.background, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.08), radius: 12, y: 4)
    }
}

import SwiftUI

struct ItemEditorView: View {
    @EnvironmentObject private var closet: ClosetStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: WardrobeItem
    @State private var showDelete = false
    private let categories = ["Tops", "Bottoms", "Outerwear", "Shoes", "Accessories", "One-piece"]

    init(item: WardrobeItem) { _draft = State(initialValue: item) }

    var body: some View {
        NavigationStack {
            Form {
                Section("Item") {
                    TextField("Name", text: $draft.name)
                    Picker("Category", selection: $draft.category) { ForEach(categories, id: \.self) { Text($0) } }
                    Toggle("Available", isOn: $draft.available)
                    Toggle("In laundry", isOn: $draft.dirty)
                }
                Section("AI metadata") {
                    TextField("Garment type", text: $draft.analysis.subcategory)
                    TextField("Primary color", text: $draft.analysis.primaryColor)
                    TextField("Other colors", text: listBinding(\GarmentAnalysis.secondaryColors))
                    TextField("Pattern", text: $draft.analysis.pattern)
                    TextField("Material", text: $draft.analysis.material)
                    TextField("Fit", text: $draft.analysis.fit)
                    TextField("Silhouette", text: $draft.analysis.silhouette)
                    Picker("Formality", selection: $draft.analysis.formality) {
                        ForEach(["Casual", "Smart Casual", "Dressy", "Unknown"], id: \.self) { Text($0) }
                    }
                    TextField("Seasons", text: listBinding(\GarmentAnalysis.season))
                    TextField("Style tags", text: listBinding(\GarmentAnalysis.styleTags))
                    TextField("Layering", text: $draft.analysis.layering, axis: .vertical)
                    TextField("Works with", text: listBinding(\GarmentAnalysis.bestColorPartners))
                    TextField("Avoid with", text: listBinding(\GarmentAnalysis.avoidColorPartners))
                    TextField("Styling notes", text: $draft.analysis.stylingNotes, axis: .vertical)
                    LabeledContent("AI confidence", value: draft.analysis.confidence.formatted(.percent.precision(.fractionLength(0))))
                }
                Section { Button("Delete item", role: .destructive) { showDelete = true } }
            }
            .navigationTitle("Edit Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { Task { await closet.update(draft); dismiss() } }.disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .confirmationDialog("Delete this wardrobe item?", isPresented: $showDelete, titleVisibility: .visible) {
                Button("Delete", role: .destructive) { Task { await closet.delete(draft); dismiss() } }
            }
        }
    }

    private func listBinding(_ path: WritableKeyPath<GarmentAnalysis, [String]>) -> Binding<String> {
        Binding(
            get: { draft.analysis[keyPath: path].joined(separator: ", ") },
            set: { draft.analysis[keyPath: path] = $0.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }
        )
    }
}


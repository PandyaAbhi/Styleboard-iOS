import SwiftUI

struct StylistView: View {
    @EnvironmentObject private var closet: ClosetStore
    @State private var context = OutfitContext(occasion: "Casual", vibe: "Clean and minimal", notes: "", season: "", temperatureC: nil)
    @State private var temperature = ""

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                GroupBox("What are you dressing for?") {
                    VStack(spacing: 12) {
                        Picker("Occasion", selection: $context.occasion) { ForEach(["Casual", "Date night", "Dinner", "Work", "Weekend", "Party"], id: \.self) { Text($0) } }
                        Picker("Vibe", selection: $context.vibe) { ForEach(["Clean and minimal", "Relaxed", "Smart casual", "Bold"], id: \.self) { Text($0) } }
                        Picker("Season", selection: $context.season) { ForEach(["", "Spring", "Summer", "Fall", "Winter"], id: \.self) { Text($0.isEmpty ? "Any season" : $0) } }
                        TextField("Temperature in °C (optional)", text: $temperature).keyboardType(.numbersAndPunctuation).textFieldStyle(.roundedBorder)
                        TextField("Context, weather, comfort or dress code", text: $context.notes, axis: .vertical).textFieldStyle(.roundedBorder).lineLimit(3...6)
                        Button { Task { context.temperatureC = Double(temperature); await closet.generate(context: context) } } label: { Label("Generate looks", systemImage: "sparkles") }
                            .buttonStyle(.borderedProminent).controlSize(.large).disabled(closet.isLoading)
                    }.padding(.top, 6)
                }
                if closet.isLoading { ProgressView("Your stylist is considering your wardrobe…").padding() }
                if let notice = closet.notice { Text(notice).font(.footnote).foregroundStyle(.secondary) }
                ForEach(closet.generated) { OutfitCard(outfit: $0) }
                if closet.generated.isEmpty && !closet.isLoading {
                    ContentUnavailableView("Ready when you are", systemImage: "sparkles", description: Text("Add analyzed clothes, then describe the occasion and vibe."))
                }
            }
            .padding()
        }
        .safeAreaInset(edge: .top, spacing: 0) { BrandSectionHeader(title: "Stylist") }
        .toolbar(.hidden, for: .navigationBar)
    }
}

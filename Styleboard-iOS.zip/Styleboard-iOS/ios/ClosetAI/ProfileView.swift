import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var closet: ClosetStore
    @State private var notes = ""
    @State private var confirmDelete = false

    var body: some View {
        Form {
            Section("Your style") {
                TextField("Fits, colors, comfort needs and styles to avoid", text: $notes, axis: .vertical).lineLimit(4...8)
                Button("Save preferences") { Task { await closet.savePreferences(notes) } }
                if let profile = closet.profile {
                    LabeledContent("Preferred colors", value: profile.preferredColors.joined(separator: ", ").nilIfEmpty ?? "Still learning")
                    LabeledContent("Styles", value: profile.preferredStyles.joined(separator: ", ").nilIfEmpty ?? "Still learning")
                    LabeledContent("Fits", value: profile.preferredFits.joined(separator: ", ").nilIfEmpty ?? "Still learning")
                    LabeledContent("Feedback signals", value: String(profile.feedbackCount))
                }
            }

            Section("Privacy") {
                Label("Stored privately on this iPhone", systemImage: "iphone.and.arrow.forward")
                Text("Photos, wardrobe details, outfits, feedback and your style profile remain inside this app. Styleboard does not require an account or server.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            Section {
                Button("Delete all local data", role: .destructive) { confirmDelete = true }
            }
        }
        .safeAreaInset(edge: .top, spacing: 0) { BrandSectionHeader(title: "My Style") }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { notes = closet.profile?.notes ?? "" }
        .onChange(of: closet.profile) { _, profile in notes = profile?.notes ?? "" }
        .confirmationDialog("Delete your entire wardrobe?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Delete everything", role: .destructive) { Task { await closet.deleteAllData() } }
        } message: {
            Text("This permanently removes the app's photos, wardrobe, outfits and feedback from this iPhone.")
        }
    }
}

private extension String { var nilIfEmpty: String? { isEmpty ? nil : self } }

import SwiftUI

struct SavedView: View {
    @EnvironmentObject private var closet: ClosetStore
    var body: some View {
        ScrollView {
            if closet.saved.isEmpty {
                ContentUnavailableView("No saved outfits", systemImage: "heart", description: Text("Save a generated look and it will appear here."))
                    .padding(.top, 80)
            } else {
                LazyVStack(spacing: 16) { ForEach(closet.saved) { OutfitCard(outfit: $0) } }.padding()
            }
        }
        .safeAreaInset(edge: .top, spacing: 0) { BrandSectionHeader(title: "Saved Outfits") }
        .toolbar(.hidden, for: .navigationBar)
    }
}

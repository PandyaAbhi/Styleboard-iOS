import Foundation

struct GarmentAnalysis: Codable, Equatable, Sendable {
    var name: String
    var category: String
    var subcategory: String
    var primaryColor: String
    var secondaryColors: [String]
    var pattern: String
    var material: String
    var fit: String
    var silhouette: String
    var formality: String
    var season: [String]
    var styleTags: [String]
    var layering: String
    var bestColorPartners: [String]
    var avoidColorPartners: [String]
    var stylingNotes: String
    var confidence: Double
}

struct WardrobeItem: Identifiable, Equatable, Sendable {
    let id: UUID
    var name: String
    var category: String
    var imageURL: URL
    var available: Bool
    var dirty: Bool
    var analysis: GarmentAnalysis
    let createdAt: Date
    var updatedAt: Date
}

struct OutfitContext: Codable, Equatable, Sendable {
    var occasion: String
    var vibe: String
    var notes: String
    var season: String
    var temperatureC: Double?
}

struct Outfit: Identifiable, Equatable, Sendable {
    let id: UUID
    let itemIDs: [UUID]
    let score: Double
    let vibe: String
    let reason: String
    let styling: String
    let occasion: String
    let context: OutfitContext
    var saved: Bool
    var feedback: String?
    let createdAt: Date
}

struct StyleProfile: Codable, Equatable, Sendable {
    let preferredColors: [String]
    let preferredStyles: [String]
    let preferredFits: [String]
    let avoidStyles: [String]
    var notes: String
    let feedbackCount: Int
}

enum LocalClosetError: LocalizedError {
    case storageUnavailable
    case insufficientWardrobe

    var errorDescription: String? {
        switch self {
        case .storageUnavailable: "Styleboard could not access its private on-device storage."
        case .insufficientWardrobe: "Add available tops, bottoms and shoes—or a one-piece and shoes—to generate outfits."
        }
    }
}

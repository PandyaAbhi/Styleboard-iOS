import SwiftData
import SwiftUI

struct RootView: View {
    @EnvironmentObject private var closet: ClosetStore
    @Environment(\.modelContext) private var modelContext

    var body: some View {
        TabView {
            NavigationStack { WardrobeView() }
                .tabItem { Label("Wardrobe", systemImage: "hanger") }
            NavigationStack { StylistView() }
                .tabItem { Label("Stylist", systemImage: "sparkles") }
            NavigationStack { SavedView() }
                .tabItem { Label("Saved", systemImage: "heart.fill") }
            NavigationStack { ProfileView() }
                .tabItem { Label("My Style", systemImage: "person.crop.circle") }
        }
        .tint(Color(red: 0.08, green: 0.46, blue: 0.92))
        .alert("Styleboard", isPresented: Binding(get: { closet.errorMessage != nil }, set: { if !$0 { closet.errorMessage = nil } })) {
            Button("OK") { closet.errorMessage = nil }
        } message: { Text(closet.errorMessage ?? "") }
        .task {
            closet.configure(modelContext)
            await closet.loadAll()
        }
    }
}

struct BrandSectionHeader<Trailing: View>: View {
    let title: String
    let trailing: Trailing

    init(title: String, @ViewBuilder trailing: () -> Trailing) {
        self.title = title
        self.trailing = trailing()
    }

    var body: some View {
        HStack(spacing: 9) {
            Image("BrandMark")
                .resizable()
                .scaledToFit()
                .frame(width: 26, height: 18)
                .accessibilityHidden(true)
            Text(title)
                .font(.headline)
            Spacer()
            trailing
        }
        .padding(.horizontal, 16)
        .frame(height: 44)
        .background(.bar)
        .overlay(alignment: .bottom) { Divider() }
    }
}

extension BrandSectionHeader where Trailing == EmptyView {
    init(title: String) {
        self.init(title: title) { EmptyView() }
    }
}

import Foundation
import SwiftData

@Model
final class WardrobeRecord {
    @Attribute(.unique) var id: UUID
    var name: String
    var category: String
    var imageFilename: String
    var available: Bool
    var dirty: Bool
    var analysisData: Data
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID, name: String, category: String, imageFilename: String, available: Bool = true, dirty: Bool = false, analysisData: Data, createdAt: Date = .now, updatedAt: Date = .now) {
        self.id = id
        self.name = name
        self.category = category
        self.imageFilename = imageFilename
        self.available = available
        self.dirty = dirty
        self.analysisData = analysisData
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

@Model
final class OutfitRecord {
    @Attribute(.unique) var id: UUID
    var itemIDsData: Data
    var score: Double
    var vibe: String
    var reason: String
    var styling: String
    var occasion: String
    var contextData: Data
    var saved: Bool
    var feedback: String?
    var createdAt: Date

    init(outfit: Outfit) throws {
        id = outfit.id
        itemIDsData = try LocalCodec.encoder.encode(outfit.itemIDs)
        score = outfit.score
        vibe = outfit.vibe
        reason = outfit.reason
        styling = outfit.styling
        occasion = outfit.occasion
        contextData = try LocalCodec.encoder.encode(outfit.context)
        saved = outfit.saved
        feedback = outfit.feedback
        createdAt = outfit.createdAt
    }
}

@Model
final class StyleProfileRecord {
    @Attribute(.unique) var key: String
    var preferenceNotes: String
    var derivedProfileData: Data
    var updatedAt: Date

    init(key: String = "primary", preferenceNotes: String = "", derivedProfileData: Data = Data(), updatedAt: Date = .now) {
        self.key = key
        self.preferenceNotes = preferenceNotes
        self.derivedProfileData = derivedProfileData
        self.updatedAt = updatedAt
    }
}

enum LocalCodec {
    static let encoder = JSONEncoder()
    static let decoder = JSONDecoder()
}

enum LocalImageStore {
    static func save(_ data: Data, id: UUID) throws -> String {
        let fileManager = FileManager.default
        let filename = "\(id.uuidString.lowercased()).jpg"
        let destination = try imagesDirectory().appendingPathComponent(filename)
        try data.write(to: destination, options: .atomic)
        try? fileManager.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
        return filename
    }

    static func url(for filename: String) -> URL {
        (try? imagesDirectory())?.appendingPathComponent(filename) ?? FileManager.default.temporaryDirectory.appendingPathComponent(filename)
    }

    static func remove(_ filename: String) {
        try? FileManager.default.removeItem(at: url(for: filename))
    }

    private static func imagesDirectory() throws -> URL {
        let fileManager = FileManager.default
        guard let applicationSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { throw LocalClosetError.storageUnavailable }
        let directory = applicationSupport.appendingPathComponent("ClosetAI/Images", isDirectory: true)
        try fileManager.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        return directory
    }
}

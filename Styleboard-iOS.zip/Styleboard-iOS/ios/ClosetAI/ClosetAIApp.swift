import SwiftData
import SwiftUI

@main
struct StyleboardApp: App {
    @StateObject private var closet = ClosetStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(closet)
        }
        .modelContainer(for: [WardrobeRecord.self, OutfitRecord.self, StyleProfileRecord.self])
    }
}

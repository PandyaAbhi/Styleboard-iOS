import Foundation
import SwiftData

@MainActor
final class ClosetStore: ObservableObject {
    @Published private(set) var items: [WardrobeItem] = []
    @Published private(set) var generated: [Outfit] = []
    @Published private(set) var saved: [Outfit] = []
    @Published private(set) var profile: StyleProfile?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var notice: String?

    private var context: ModelContext?
    private var itemRecords: [UUID: WardrobeRecord] = [:]
    private var outfitRecords: [UUID: OutfitRecord] = [:]
    private var profileRecord: StyleProfileRecord?

    func configure(_ context: ModelContext) {
        if self.context == nil { self.context = context }
    }

    func loadAll() async {
        guard let context else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            let itemDescriptor = FetchDescriptor<WardrobeRecord>(sortBy: [SortDescriptor(\WardrobeRecord.updatedAt, order: .reverse)])
            let outfitDescriptor = FetchDescriptor<OutfitRecord>(sortBy: [SortDescriptor(\OutfitRecord.createdAt, order: .reverse)])
            let records = try context.fetch(itemDescriptor)
            let history = try context.fetch(outfitDescriptor)
            profileRecord = try context.fetch(FetchDescriptor<StyleProfileRecord>()).first
            itemRecords = Dictionary(uniqueKeysWithValues: records.map { ($0.id, $0) })
            outfitRecords = Dictionary(uniqueKeysWithValues: history.map { ($0.id, $0) })
            items = records.compactMap(item(from:))
            let outfits = history.compactMap(outfit(from:))
            generated = Array(outfits.prefix(3))
            saved = outfits.filter(\.saved)
            try refreshProfile(persist: true)
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    func upload(_ jpegData: Data, analysis: GarmentAnalysis) async {
        guard let context else { return }
        isLoading = true
        defer { isLoading = false }
        let id = UUID()
        var filename: String?
        do {
            filename = try LocalImageStore.save(jpegData, id: id)
            let now = Date()
            let record = WardrobeRecord(id: id, name: analysis.name, category: analysis.category, imageFilename: filename!, analysisData: try LocalCodec.encoder.encode(analysis), createdAt: now, updatedAt: now)
            context.insert(record)
            try context.save()
            itemRecords[id] = record
            if let item = item(from: record) { items.insert(item, at: 0) }
            try refreshProfile(persist: true)
            errorMessage = nil
        } catch {
            if let filename { LocalImageStore.remove(filename) }
            errorMessage = error.localizedDescription
        }
    }

    func update(_ item: WardrobeItem) async {
        guard let context, let record = itemRecords[item.id] else { return }
        do {
            record.name = item.name.trimmingCharacters(in: .whitespacesAndNewlines)
            record.category = item.category
            record.available = item.available
            record.dirty = item.dirty
            record.analysisData = try LocalCodec.encoder.encode(item.analysis)
            record.updatedAt = .now
            try context.save()
            if let index = items.firstIndex(where: { $0.id == item.id }), let updated = self.item(from: record) { items[index] = updated }
            try refreshProfile(persist: true)
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    func delete(_ item: WardrobeItem) async {
        guard let context, let record = itemRecords[item.id] else { return }
        do {
            let relatedOutfits = outfitRecords.values.filter { decodedItemIDs($0).contains(item.id) }
            for outfitRecord in relatedOutfits {
                context.delete(outfitRecord)
                outfitRecords.removeValue(forKey: outfitRecord.id)
            }
            context.delete(record)
            try context.save()
            LocalImageStore.remove(record.imageFilename)
            itemRecords.removeValue(forKey: item.id)
            items.removeAll { $0.id == item.id }
            refreshOutfitLists()
            try refreshProfile(persist: true)
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    func generate(context outfitContext: OutfitContext) async {
        guard let context else { return }
        isLoading = true
        notice = nil
        defer { isLoading = false }
        do {
            let history = outfitRecords.values.compactMap(outfit(from:)).sorted { $0.createdAt > $1.createdAt }
            let currentProfile = profile ?? LocalStylist.deriveProfile(items: items, outfits: history, notes: profileRecord?.preferenceNotes ?? "")
            let result = try LocalStylist.generate(items: items, recent: history, profile: currentProfile, context: outfitContext)
            for outfit in result.outfits {
                let record = try OutfitRecord(outfit: outfit)
                context.insert(record)
                outfitRecords[outfit.id] = record
            }
            try context.save()
            generated = result.outfits
            notice = result.notice.isEmpty ? nil : result.notice
            try refreshProfile(persist: true)
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    func setFeedback(_ outfit: Outfit, feedback: String? = nil, saved newSaved: Bool? = nil) async {
        guard let context, let record = outfitRecords[outfit.id] else { return }
        do {
            if let feedback { record.feedback = feedback }
            if let newSaved { record.saved = newSaved }
            try context.save()
            refreshOutfitLists()
            try refreshProfile(persist: true)
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    func savePreferences(_ notes: String) async {
        guard let context else { return }
        do {
            let record: StyleProfileRecord
            if let profileRecord { record = profileRecord }
            else {
                record = StyleProfileRecord()
                context.insert(record)
                profileRecord = record
            }
            record.preferenceNotes = String(notes.prefix(2_000))
            record.updatedAt = .now
            try refreshProfile(persist: true)
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    func deleteAllData() async {
        guard let context else { return }
        do {
            for record in Array(itemRecords.values) {
                LocalImageStore.remove(record.imageFilename)
                context.delete(record)
            }
            for record in Array(outfitRecords.values) {
                context.delete(record)
            }
            if let profileRecord { context.delete(profileRecord) }
            try context.save()
            itemRecords = [:]
            outfitRecords = [:]
            profileRecord = nil
            items = []
            generated = []
            saved = []
            profile = StyleProfile(preferredColors: [], preferredStyles: [], preferredFits: [], avoidStyles: [], notes: "", feedbackCount: 0)
            notice = nil
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    private func refreshOutfitLists() {
        let outfits = outfitRecords.values.compactMap(outfit(from:)).sorted { $0.createdAt > $1.createdAt }
        generated = generated.compactMap { current in outfits.first(where: { $0.id == current.id }) }
        saved = outfits.filter(\.saved)
    }

    private func refreshProfile(persist: Bool) throws {
        guard let context else { return }
        let outfits = outfitRecords.values.compactMap(outfit(from:))
        let derived = LocalStylist.deriveProfile(items: items, outfits: outfits, notes: profileRecord?.preferenceNotes ?? "")
        profile = derived
        guard persist else { return }
        let record: StyleProfileRecord
        if let profileRecord { record = profileRecord }
        else {
            record = StyleProfileRecord()
            context.insert(record)
            profileRecord = record
        }
        record.derivedProfileData = try LocalCodec.encoder.encode(derived)
        record.updatedAt = .now
        try context.save()
    }

    private func item(from record: WardrobeRecord) -> WardrobeItem? {
        guard var analysis = try? LocalCodec.decoder.decode(GarmentAnalysis.self, from: record.analysisData) else { return nil }
        analysis.name = record.name
        analysis.category = record.category
        return WardrobeItem(id: record.id, name: record.name, category: record.category, imageURL: LocalImageStore.url(for: record.imageFilename), available: record.available, dirty: record.dirty, analysis: analysis, createdAt: record.createdAt, updatedAt: record.updatedAt)
    }

    private func outfit(from record: OutfitRecord) -> Outfit? {
        guard let itemIDs = try? LocalCodec.decoder.decode([UUID].self, from: record.itemIDsData),
              let context = try? LocalCodec.decoder.decode(OutfitContext.self, from: record.contextData) else { return nil }
        return Outfit(id: record.id, itemIDs: itemIDs, score: record.score, vibe: record.vibe, reason: record.reason, styling: record.styling, occasion: record.occasion, context: context, saved: record.saved, feedback: record.feedback, createdAt: record.createdAt)
    }

    private func decodedItemIDs(_ record: OutfitRecord) -> [UUID] {
        (try? LocalCodec.decoder.decode([UUID].self, from: record.itemIDsData)) ?? []
    }
}
